
        fun main() {

            println("Я ЗАГАДАЛ ЧИСЛО ОТ 0 ДО 100")
            println("У ТЕБЯ 7 ПОПЫТОК ЕГО ОТГАДАТЬ")
            println("ПОЕХАЛИ!")

            val randomInteger = (0 until 100).random()
            var ch = randomInteger

            for(i in 1..7)
            {
                val a = readLine()!!.toInt()
                ch = a
                if
                        (a == randomInteger)
                        {
                            println("Вы угадали!")
                            break
                        }

                else if (a > randomInteger)

                         println("Вы не угадали. Загаданное число меньше.")

                else

                         println("Вы не угадали. Загаданное число больше.")

            }


            if (ch != randomInteger)
                println("Я загадал число $randomInteger")

        }

